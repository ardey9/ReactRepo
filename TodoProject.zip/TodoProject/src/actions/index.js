export const SET_TAG='SET_TAG';
export const All_TAGS='All_TAGS';
export const SAVE_TAG='SAVE_TAG';
export const SHOW_NOTE='SHOW_NOTE';
export const DELETE_NOTE='DELETE_NOTE';
export const FILTER_NOTE='FILTER_NOTE';
export const SORT_TAG='SORT_TAG';

export function setTags(tagL1,tagL2){
   const action = {
        type:SET_TAG,
        tagL1,
        tagL2
    }
    return action;
}

export function allTags(){
    const action = {
         type:All_TAGS
    }
     return action;
 }

 export function saveTag(form){
    
    const action = {
         type:SAVE_TAG,
         form
         
    }
     return action;
 }


 export function showNote(note){
    const action = {
         type:SHOW_NOTE,
         note
    }
     return action;
 }

 export function deleteNote(note){
    const action = {
         type:DELETE_NOTE,
         note
    }
     return action;
 }

 export function filterNote(textSearch){
    const action = {
         type:FILTER_NOTE,
         textSearch
    }
     return action;
 }

 export function sortTag(sortedTags){
    const action = {
         type:SORT_TAG,
         sortedTags
    }
     return action;
 }