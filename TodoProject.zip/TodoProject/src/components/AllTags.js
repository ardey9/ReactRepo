import React, { Component } from 'react';
import { Form , FormControl , ControlLabel , Button, FormGroup,Modal , 
    ModalHeader, ModalBody,ModalFooter,ModalTitle, Label , Dropdown } from 'react-bootstrap';
import { connect } from  'react-redux';
import  { setTags,saveTag,sortTag } from '../actions';
import NewTag from './NewTag';
import { bindActionCreators} from 'redux';
import ModalComponent from '../components/ModalComponent';
import DateTime from 'react-datetime';

class AllTags extends Component {
    
    constructor(){
        super();
        this.state = {
            tagLabel : '',
            tagLabelSecond:'',
            tagLabelThird:'',
            parentLabel : '',
            noteBody:'',
            noteHeader:'',
            noteDate:'',
            modalName:'',
            placeholderName:'',
            showModal:false,
            showModalNote:false,
            noteCreationDate:'',
            sortTag:''
        }
        
    }
    
   
    render (){
        console.log('this.props : ',this.props);
        console.log('this.state : ',this.state);
       
        return (
            
            <div > 
                <Form>
            {sortTagsByLevel(this.props.tags)}
                     <FormGroup>
                        {/* <FormControl id="addtag"
                        type = "text" placeholder="Add Tag" className = "list-group"
                        onChange={event=>this.setState({tagLabel:event.target.value})}
                        
                        />  */}
                           <Button onClick={()=>{this.setState({showModalNote:true,noteCreationDate:new Date()});
                           this.setState({modalName:'Add New Note'});
                           this.setState({placeholderName:'Add Note here...'})}}> New Note</Button>
                        </FormGroup>   

                         <FormGroup>
                             
                         {this.props.tags.map((tagname,index)=>{
                              return (
                              <ul key={ index } className="list-group-item">
                              {/* <div onClick={()=>this.addNote(tagname)}>-</div> */}
                             
                              {tagname!=="All Tags" ? 

                              <div  onClick={()=>this.setState({tagLabelSecond:tagname.substring(0,tagname.indexOf(":"))})}>
                                <ul>
                                 {'- '+checkParentNode(tagname)}({totalTags(checkParentNode(tagname),this.props.addnote)})
                                </ul>
                              </div>
                              :
                              <div className="list-item">
                              {tagname}
                            </div>
                            }
                              </ul>)
                         })} 
                        
                        </FormGroup> 
                    </Form>
                {' '}
                
                <Button onClick={()=>{this.setState({showModal:true});this.setState({modalName:'Add New Tag'});this.setState({placeholderName:'Add Tag'})}} 
                className="button">Add New tag</Button>
                
                <div>
               <Modal show ={this.state.showModal} onHide={()=>{this.setState({showModal:false})}} >
               <ModalHeader title={this.state.modalName} closeButton>
               <ModalTitle>{this.state.modalName} </ModalTitle>
               </ModalHeader>
                        <ModalBody>
                                <FormGroup>
                                    <FormControl placeholder={this.state.placeholderName} type="textarea" 
                                    onChange={event=>this.setState({tagLabel:event.target.value})}
                                    />
                                </FormGroup>
                             </ModalBody>
                    <ModalFooter>
                      
                        <Button onClick={()=>{this.state.tagLabel.trim()!==''?this.props.setTags(this.state.tagLabel,this.state.tagLabelSecond):tagValidation(this.state.tagLabel);
                        this.setState({showModal:false,tagLabel:'',tagLabelSecond:''})}} >Save</Button>
                        {' '}
                        <Button onClick={()=>{this.setState({showModal:false})}}>Close</Button>
                    </ModalFooter>
                        
                </Modal>
            </div>
            <div>
               <Modal show ={this.state.showModalNote} onHide={()=>{this.setState({showModalNote:false})}} >
               <ModalHeader title={this.state.modalName} closeButton>
               <ModalTitle>{this.state.modalName} </ModalTitle>
               </ModalHeader>
                        <ModalBody>
                                <Form >
                                    <FormGroup>
                                    <div>
                                    <label>Choose tag to add note : </label>
                                    {' '}
                                    <select onChange={event=>this.setState({tagLabel:event.target.value})}>
                                
                                    {this.props.tags.map(function(tagname,index){
                                    return (
                                    
                                    tagname ==='All Tags'? <option key={ index } value={tagname} >{tagname}</option>
                                    :
                                    <option key={ index } value={listOfParentTag(tagname)} >
                                        {listOfParentTag(tagname)}
                                    </option>
                                    
                                    )
                                        })} 
                                    </select>
                                </div>
                                        <FormControl type="text" placeholder="Type header of the note..."
                                        onChange={event=>this.setState({noteHeader:event.target.value}) }/>

                                        <label>Due Date : </label>
                                        <input  type="date"  format='DD MMM YYYY, hh:mm a' onChange={event=>this.setState({noteDate:event.target.value}) }/>
        
                                        <FormControl type="textarea" placeholder="Type body of the note..." 
                                        onChange={event=>this.setState({noteBody:event.target.value}) }/>
                                    </FormGroup>    
                                </Form>
                             </ModalBody>
                    <ModalFooter>
                      
                        <Button onClick={()=>{this.state.tagLabel.trim()!==''?this.props.saveTag(this.state) :selectTagValidation(this.state.tagLabel);this.setState({showModalNote:false,tagLabel:''})}}>Save</Button>
                        {' '}
                        <Button onClick={()=>{this.setState({showModalNote:false})}}>Close</Button>
                    </ModalFooter>
                        
                </Modal>
            </div>         
            </div>
    
        )
        
    }
     
}
 


function mapStateToProps(state){
    return state;

}
function listOfParentTag(tagname){
    let tempParTag='';
    if(tagname.indexOf(":NA")>0){
        tempParTag=tagname.substring(0,tagname.indexOf(":NA"));
    }
    else {
        tempParTag = tagname.substring(tagname.indexOf(":")+1);
    }
    return tempParTag;
  }
function checkParentNode(tagname){
    let tempParTag='';
    let listOfParentTag=[];
    if(tagname.indexOf(":NA")>0){
        tempParTag=tagname.substring(0,tagname.indexOf(":NA"));
        listOfParentTag=[...listOfParentTag,tempParTag];
    }
    else {
        tempParTag = tagname.substring(tagname.indexOf(":")+1);
        listOfParentTag=[...listOfParentTag,tempParTag];
    }
    return tempParTag;
  }
function selectTagValidation(tagname){
    if(tagname.trim()===""){
      alert("Add or select proper tags");
    }
  }
  function tagValidation(tagname){
    if(tagname.trim()===""){
      alert("Add a new tag");
    }
    
  }
function totalTags (name,notes) {
    let totaltags = 0;
    notes.map((note,index)=>{
        if(note.tagLabel===name)
        {
            totaltags++;
        }
    });
    return totaltags;
}

function sortTagsByLevel (tags){
    let parentTags=[];
    let childTags='';
    let sorted  ='';
    if(tags.length !==1){
        tags.map((tagname,index)=>{
            if(tagname.tagL1!=='' && tagname.tagL2==='')
            {
                parentTags = [...parentTags,tagname.tagL1]
                childTags=[...childTags ,tagname.tagL1+":NA"]
            }
            else if(tagname.tagL1!=='' && tagname.tagL2!=='')
            {
                parentTags.map((tag,index)=>{
                    if(tag===tagname.tagL2){
                        childTags = [...childTags ,tagname.tagL2+":"+tagname.tagL1]
                    }
                })
            }
        })
    }
    if(childTags!==''){
     sorted = childTags.sort(function(a,b){
        if (a < b) return -1;
        else if (a > b) return 1;
        return 0;
    });
}
    console.log('sorted',sorted);
    return sorted;
}
// function mapDispatchToProps(dispatch){
//    return bindActionCreators({setTags},dispatch);
// }

export default connect (mapStateToProps,{ setTags ,saveTag,sortTag})(AllTags);