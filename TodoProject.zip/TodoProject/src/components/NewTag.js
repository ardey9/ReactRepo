import React, { Component } from 'react';
import { Form , FormControl , ControlLabel , Button, FormGroup } from 'react-bootstrap';

class NewTag extends Component {
render(){
    return(
         <div>
            <Form>
             <FormGroup>
                 <FormControl 
                 type = "text" placeholder="New tag" required="true"
                 />
                 </FormGroup>
                 
             </Form>
         </div>
    )
};
}
export default NewTag;