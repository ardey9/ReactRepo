import React, { Component } from 'react';
import { connect } from  'react-redux';

class SelectTags extends Component{

    render(){
        return(
            <div>
                <label>Choose tag to add note : </label>
                {' '}
                <select title="Choose tag for note add">
                        
                           {this.props.state.map(function(tagname,index){
                              return (
                              <option key={ index } value={tagname}>
                              {tagname}
                              </option>)
                         })} 
                        </select>
            </div>
        )
    }
}
function mapStateToProps(state){
    return {state};
}

export default connect (mapStateToProps,null)(SelectTags);