import React, { Component } from 'react';
import { connect } from  'react-redux';
import { Form , FormControl , ControlLabel , Button, FormGroup ,Dropdown,DropdownButton,MenuItem } from 'react-bootstrap';
import { bindActionCreators} from 'redux';
import { deleteNote } from '../actions';
import Moment from 'moment';


class NoteArea extends Component {

    constructor(props) {
        super(props);
        this.state = {value: 'Investor meeting with client'};
    
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
    
      handleChange(event) {
        this.setState({value: event.target.value});
      }
    
      handleSubmit(event) {
        alert('An essay was submitted: ' + this.state.value);
        event.preventDefault();
      }
    
      render() {
        Moment.locale('en');
        console.log('this.props_NoteArea : ',this.props);
        let noteToDisplay = this.props.showNote;
        return (
        <div className="note-area">
          <form onSubmit={this.handleSubmit}>
          {noteToDisplay.length===0?<div/>:
                 <div className="note-filter">
                      <FormGroup className = "list-group">
                      <h1>{noteToDisplay.noteHeader} </h1>
                      <h3>{noteToDisplay.noteBody}  </h3>
                      <h4>Creation date:{Moment(noteToDisplay.noteCreationDate).format('DD MMM YYYY, hh:mm a')}</h4>
                      <h4>Due date : {Moment(noteToDisplay.noteDate).format('DD MMM YYYY, hh:mm a')}</h4>
                      </FormGroup>
                   
                  </div>
          }
            <div>
            {
              this.props.showNote.length=== 0? "":
            <Button onClick={()=>{this.props.deleteNote(noteToDisplay)}}>Delete</Button>
            }
            </div>
          </form>
          </div>
          
        );
      }
}
function mapStateToProps(state){
  return state;

}
export default connect (mapStateToProps,{deleteNote})(NoteArea);