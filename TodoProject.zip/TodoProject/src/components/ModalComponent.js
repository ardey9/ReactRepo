import React, { Component } from 'react';
import { Modal ,ModalHeader,Form,FormGroup,FormControl,ModalBody,ModalFooter,Button} from 'react-bootstrap';

class ModalComponent extends Component {
    constructor(){
        super();
        this.state = {
            showModal:false,
            formProcessing:'',
            email:''
        }
        this.toggleModal=false;
        this.submitForm='';
        this.submitButton='Submit';
    }
    close() {
        this.setState({ showModal: false });
      }
    
      open() {
        this.setState({ showModal: true });
      }
    render(){
        
        return (
            <div>
               <Modal show ={this.state.showModal} onHide= {this.toggleModal} backdropClosesModal>
                    <ModalHeader text="Live Demo" showCloseButton onClose={this.toggleModal} />
                        <form action="#" onSubmit={this.submitForm} noValidate>
                            <ModalBody>
                                <FormGroup label="Email">
                                    <FormControl label="Email" type="email" name="email" ref="email" value={this.state.email}  required />
                                </FormGroup>
                             </ModalBody>
                    <ModalFooter>
                        {this.submitButton}
                        <Button onClick={this.toggleModal} type="link-cancel" disabled={this.state.formProcessing}>Cancel</Button>
                    </ModalFooter>
                        </form>
                </Modal>
            </div>
        )
    }
}
export default ModalComponent;