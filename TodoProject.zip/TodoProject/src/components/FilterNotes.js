import React, { Component } from 'react';
import { connect } from  'react-redux';
import { Form , FormControl , ControlLabel , Button, FormGroup ,Dropdown,DropdownButton,MenuItem } from 'react-bootstrap';
import { bindActionCreators} from 'redux';
import { showNote,filterNote } from '../actions';
import Moment from 'moment';





class FilterNotes extends Component {

    constructor() {
        super();
       this.state={
          sortBy:''
       }
      }
       
    render() {
      Moment.locale('en');
      console.log('this.props_Filter : ',this.props);
        return (
            <Form>
                     <FormGroup>
                       <FormControl id="searchfilter"
                        type = "text" placeholder="Search and Filter.." 
                        onChange={event=>{this.setState({tagLabel:event.target.value});this.props.filterNote(event.target.value)}}
                        />
                        </FormGroup> 
                         <FormGroup >
                            
                            <select title="Search and Filter.." onChange={event=>this.setState({sortBy:event.target.value})}>
                            <option value="nothing" >Search and Filter..</option>
                            <option value="name" >Sort by Name</option>
                            <option value="creation" >Sort by Creation date</option>
                            <option value="due">Sort by Due date</option>
                          </select>
                        
                        </FormGroup> 
                        <div>
                      {this.state.sortBy==='due' ?
                        <div className="note-filter">
                        <FormGroup >
                          <ul>  
                            {this.props.addnote.sort((a,b)=>a.noteDate>b.noteDate)
                            .map((note,index)=>{
                              return (
                                <ul key={index}>
                                    <div onClick={()=>this.props.showNote(note)}>
                                    <h1>{note.noteHeader.substring(0,10)+"..."} </h1>
                                    <h3>{note.noteBody.substring(0,10)+"..."}  </h3>
                                    <h4>Creation date:{Moment(note.noteCreationDate).format('DD MMM YYYY, hh:mm a')}</h4>
                                    <h4>Due date : {Moment(note.noteDate).format('DD MMM YYYY, hh:mm a')}</h4>
                                    </div>
                                  </ul>
                              )
                            })}
                            </ul>
                        </FormGroup>
                        </div>
                        :
                        this.state.sortBy==='name'?
                        <div className="note-filter">
                        <FormGroup >
                          <ul>  
                            {this.props.addnote.sort((a,b)=>a.noteHeader>b.noteHeader)
                            .map((note,index)=>{
                              return (
                                <ul key={index}>
                                    <div onClick={()=>this.props.showNote(note)}>
                                    <h1>{note.noteHeader.substring(0,10)+"..."} </h1>
                                    <h3>{note.noteBody.substring(0,10)+"..."}  </h3>
                                    <h4>Creation date:{Moment(note.noteCreationDate).format('DD MMM YYYY, hh:mm a')}</h4>
                                    <h4>Due date : {Moment(note.noteDate).format('DD MMM YYYY, hh:mm a')}</h4>
                                    </div>
                                  </ul>
                              )
                            })}
                            </ul>
                        </FormGroup>
                        </div>
                        :
                        <div  className="note-filter">
                          <FormGroup >
                          <ul>  
                            {this.props.addnote.map((note,index)=>{
                              return (
                                <ul key={index}>
                                    <div onClick={()=>this.props.showNote(note)}>
                                    <h1>{note.noteHeader.substring(0,10)+"..."} </h1>
                                    <h3>{note.noteBody.substring(0,10)+"..."}  </h3>
                                    <h4>Creation date:{Moment(note.noteCreationDate).format('DD MMM YYYY, hh:mm a')}</h4>
                                    <h4>Due date : {Moment(note.noteDate).format('DD MMM YYYY, hh:mm a')}</h4>
                                    </div>
                                  </ul>
                              )
                            })}
                            </ul>
                        </FormGroup>
                          </div>
                      }
                      </div>
                    </Form>
        );
      }

}
function sortNote(sortBy){
  alert(sortBy);
}
function mapStateToProps(state){
  return state;

}
export default connect (mapStateToProps,{showNote,filterNote})(FilterNotes);
