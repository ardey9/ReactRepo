import React, { Component } from 'react';
import AllTags from './AllTags';
import NoteArea from './NoteArea';
import FilterNotes from './FilterNotes';
import '../styles/index.css'

class App extends Component {
    render (){
        return (
            <div className="App"> 
                <h2>Wipro-MyNotes</h2>
                <div className="col-md-4">
                <AllTags/>
                </div>
                <div className="col-md-4">
                <FilterNotes/>
                </div>
                <div className="col-md-4">
                <NoteArea/>
                </div>
            </div>
        )
    }
}

export default App;