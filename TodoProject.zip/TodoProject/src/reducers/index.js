import { combineReducers } from 'redux';
import { SET_TAG , All_TAGS ,SAVE_TAG , SHOW_NOTE , DELETE_NOTE , FILTER_NOTE , SORT_TAG} from '../actions';
//  //import store from '../store';




function tags(state = ["All Tags"],action,sortTag='') {
switch(action.type){
    case SET_TAG:
    state = [...state,newtags(action.tagL1,action.tagL2)];
    return state.sort(function(a,b){
        if (a < b) return -1;
        else if (a > b) return 1;
        return 0;
    });
    case All_TAGS:
    return state;
    default:
    return state;
    }
}

function addnote(addform = [],action) {
    switch(action.type){
        case SAVE_TAG:
        addform = [...addform,action.form];
        return addform;
        case DELETE_NOTE:
        addform = addform.filter(element=>element!==action.note);
        return addform;
        // case FILTER_NOTE:
        // addform = addform.filter(element=>element.indexOf(action.textSearch)>=0);
        // return addform;
        default:
        return addform;
        }
    }

    function showNote(showNote = [],action) {
        switch(action.type){
            case SHOW_NOTE:
            showNote = action.note;
            return showNote;
            case DELETE_NOTE:
            showNote = [];
            return showNote;
            default:
            return showNote;
            }
        }

        function sortTags(sortTag = [],action) {
            switch(action.type){
            case SORT_TAG:
            sortTag = action.sortedTags;
            return sortTag;
            default:
            return sortTag;
            }
        }
        
function sortTagsByLevel (tags){
    let parentTags=[];
    let childTags='';
    let sorted  ='';
    if(tags.length !==1){
        tags.map((tagname,index)=>{
            if(tagname.tagL1!=='' && tagname.tagL2==='')
            {
                parentTags = [...parentTags,tagname.tagL1]
                childTags=[...childTags ,tagname.tagL1+":NA"]
            }
            else if(tagname.tagL1!=='' && tagname.tagL2!=='')
            {
                parentTags.map((tag,index)=>{
                    if(tag===tagname.tagL2){
                        childTags = [...childTags ,tagname.tagL2+":"+tagname.tagL1]
                    }
                })
            }
        })
    }
    if(childTags!==''){
     sorted = childTags.sort(function(a,b){
        if (a < b) return -1;
        else if (a > b) return 1;
        return 0;
    });
}
    console.log('sorted',sorted);
    return sorted;
}
function newtags(tagL1,tagL2){
    let currentTag = '';
    if (tagL2.trim()!=="" && tagL1.trim()!=="")
    {
        currentTag=tagL2+":"+tagL1;
        console.log('currentTag 1 :',tagL1,tagL2);
    }
    else if(tagL1.trim()!=="" && tagL2.trim()==="")
    {
        currentTag=tagL1+":NA";
        console.log('currentTag 2 :',tagL1,tagL2);
    }
    return currentTag;
}

const rootReducer = combineReducers({ tags, addnote , showNote,sortTags});
export default rootReducer;